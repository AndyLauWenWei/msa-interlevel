export class Item {

  constructor(
    public id: string,
    public quantity: number) {
      this.id = id;
      this.quantity = quantity;
     }

}
